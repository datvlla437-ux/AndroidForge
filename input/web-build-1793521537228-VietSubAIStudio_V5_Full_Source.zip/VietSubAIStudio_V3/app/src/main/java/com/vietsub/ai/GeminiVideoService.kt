package com.vietsub.ai

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class GeminiVideoService(private val context: Context) {
    suspend fun translateVideo(uri: Uri, apiKey: String, model: String, glossary: String, style: String): List<Subtitle> =
        withContext(Dispatchers.IO) {
            require(apiKey.isNotBlank()) { "Bạn chưa nhập Gemini API Key." }
            require(model.isNotBlank()) { "Bạn chưa nhập tên model." }
            val mime = context.contentResolver.getType(uri) ?: "video/mp4"
            val name = getName(uri)
            val data = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Không đọc được video.")
            require(data.isNotEmpty()) { "Video rỗng." }
            require(data.size <= 180 * 1024 * 1024) { "Video vượt giới hạn 180 MB của bản này. Hãy cắt video ngắn hơn." }

            val file = upload(apiKey, name, mime, data)
            // Gemini Files API may wrap the File resource in a top-level "file" object.
            val fileResource = file.optJSONObject("file") ?: file
            val resourceName = fileResource.optString("name")
            val fileUri = fileResource.optString("uri")
            require(resourceName.isNotBlank() && fileUri.isNotBlank()) {
                val apiMessage = file.optJSONObject("error")?.optString("message")
                "Upload Gemini thành công nhưng phản hồi thiếu file.name/file.uri. " +
                    (apiMessage?.takeIf { it.isNotBlank() } ?: "Phản hồi: ${file.toString().take(500)}")
            }
            waitActive(apiKey, resourceName)

            val prompt = """
Bạn là hệ thống tạo phụ đề phim chuyên nghiệp. Nghe lời thoại tiếng Trung trong video và dịch sang tiếng Việt.
CHỈ trả JSON hợp lệ, không Markdown. Schema:
{"subtitles":[{"start":"00:00:01.200","end":"00:00:03.500","text":"Câu tiếng Việt"}]}
Quy tắc:
- Timestamp tính từ đầu video, định dạng HH:MM:SS.mmm.
- Tạo đoạn theo từng câu/ý thoại, không gom các câu xa nhau.
- Bám sát lời nói, dịch tự nhiên, giữ tên nhân vật theo từ điển.
- Không thêm lời không có trong video. Nếu không nghe rõ, bỏ qua đoạn đó.
- Thời gian phải tăng dần, end lớn hơn start.
Phong cách: $style
Từ điển/tên nhân vật: ${glossary.ifBlank { "Không có" }}
            """.trimIndent()

            val req = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                    .put(JSONObject().put("fileData", JSONObject().put("mimeType", mime).put("fileUri", fileUri)))
                    .put(JSONObject().put("text", prompt)))))
                put("generationConfig", JSONObject().put("temperature", 0.15).put("responseMimeType", "application/json"))
            }
            val response = postJson(
                "https://generativelanguage.googleapis.com/v1beta/models/${enc(model)}:generateContent?key=${enc(apiKey)}",
                req
            )
            val answer = response.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            parse(answer)
        }

    private fun upload(key: String, filename: String, mime: String, bytes: ByteArray): JSONObject {
        // Gemini Files API requires a resumable upload (start -> upload, finalize).
        val startUrl = URL("https://generativelanguage.googleapis.com/upload/v1beta/files?key=${enc(key)}")
        val start = (startUrl.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 30_000
            readTimeout = 60_000
            setRequestProperty("X-Goog-Upload-Protocol", "resumable")
            setRequestProperty("X-Goog-Upload-Command", "start")
            setRequestProperty("X-Goog-Upload-Header-Content-Length", bytes.size.toString())
            setRequestProperty("X-Goog-Upload-Header-Content-Type", mime)
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        }
        val metadata = JSONObject().put("file", JSONObject().put("display_name", filename))
        start.outputStream.use { it.write(metadata.toString().toByteArray(Charsets.UTF_8)) }
        val startCode = start.responseCode
        val startBody = (if (startCode in 200..299) start.inputStream else start.errorStream)
            ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        val uploadUrl = start.getHeaderField("X-Goog-Upload-URL")
            ?: start.getHeaderField("x-goog-upload-url")
        start.disconnect()
        if (startCode !in 200..299) {
            val msg = try { JSONObject(startBody).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
            error("Gemini upload start HTTP $startCode: ${msg ?: startBody.take(500)}")
        }
        if (uploadUrl.isNullOrBlank()) {
            error("Gemini không trả về X-Goog-Upload-URL khi khởi tạo upload. Phản hồi: ${startBody.take(400)}")
        }

        val finish = (URL(uploadUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 30_000
            readTimeout = 180_000
            setRequestProperty("Content-Length", bytes.size.toString())
            setRequestProperty("X-Goog-Upload-Offset", "0")
            setRequestProperty("X-Goog-Upload-Command", "upload, finalize")
            setRequestProperty("Content-Type", mime)
        }
        finish.outputStream.use { it.write(bytes) }
        return read(finish)
    }

    private fun waitActive(key: String, name: String) {
        repeat(36) {
            val c = (URL("https://generativelanguage.googleapis.com/v1beta/$name?key=${enc(key)}").openConnection() as HttpURLConnection).apply {
                connectTimeout = 20_000; readTimeout = 30_000
            }
            val obj = read(c)
            when (obj.optString("state")) {
                "ACTIVE" -> return
                "FAILED" -> error("Gemini không xử lý được video.")
            }
            Thread.sleep(2_000)
        }
        error("Gemini xử lý video quá lâu. Hãy thử clip ngắn hơn.")
    }

    private fun postJson(url: String, body: JSONObject): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true
            connectTimeout = 30_000; readTimeout = 240_000
            setRequestProperty("Content-Type", "application/json")
        }
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return read(c)
    }

    private fun read(c: HttpURLConnection): JSONObject {
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (code !in 200..299) {
            val msg = try { JSONObject(body).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
            error("Gemini HTTP $code: ${msg ?: body.take(400)}")
        }
        return JSONObject(body)
    }

    private fun parse(raw: String): List<Subtitle> {
        val clean = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val arr = JSONObject(clean).getJSONArray("subtitles")
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val start = SubtitleExporter.parseTime(o.getString("start"))
                val end = SubtitleExporter.parseTime(o.getString("end"))
                val text = o.getString("text").trim()
                if (start >= 0 && end > start && text.isNotBlank()) add(Subtitle(start, end, text))
            }
        }.sortedBy { it.start }
    }

    private fun getName(uri: Uri): String {
        var n = "video.mp4"
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) n = it.getString(0) ?: n
        }
        return n
    }
    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8")
}
