package vn.vietnamlife.online

import android.app.Activity
import android.app.AlertDialog
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var game: LifeGLView
    private lateinit var hud: TextView
    private lateinit var hint: TextView
    private var riding = false
    private var indoors = false
    private var money = 2450000
    private var missionDone = false
    private var nearby = "Không có ai ở gần"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8,14,25)
        window.navigationBarColor = Color.rgb(8,14,25)
        val root = FrameLayout(this)
        game = LifeGLView(this)
        root.addView(game, FrameLayout.LayoutParams(-1,-1))
        hud = TextView(this).apply {
            text = "VIETNAM LIFE 3D   •   CẤP 08\\n₫2.450.000   •   SÀI GÒN"
            setTextColor(Color.WHITE); textSize=12f; typeface=Typeface.DEFAULT_BOLD
            setPadding(24,16,24,16); background=bg(0xDD0B1728.toInt(),18)
        }
        val hp = FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.LEFT).apply { leftMargin=18; topMargin=16 }
        root.addView(hud,hp)
        hint = TextView(this).apply {
            text="JOYSTICK: DI CHUYỂN   •   KÉO BÊN PHẢI: XOAY CAMERA"
            setTextColor(Color.WHITE); textSize=10f; setPadding(16,10,16,10)
            background=bg(0xAA0B1728.toInt(),14)
        }
        root.addView(hint,FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin=14 })
        val buttons=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
            setPadding(8,8,8,8); background=bg(0xAA0B1728.toInt(),18)
        }
        fun addBtn(label:String, click:()->Unit) {
            val b=TextView(this).apply {
                text=label; gravity=Gravity.CENTER; textSize=10f; typeface=Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE); setPadding(14,13,14,13); background=bg(0xFF263D59.toInt(),14)
                setOnClickListener { click() }
            }
            buttons.addView(b,LinearLayout.LayoutParams(112,48).apply { bottomMargin=6 })
        }
        addBtn("🏍  LÊN / XUỐNG XE") {
            riding=!riding; game.setRiding(riding); hint.text=if(riding) "ĐANG LÁI XE • JOYSTICK ĐỂ ĐIỀU KHIỂN" else "ĐI BỘ • JOYSTICK ĐỂ DI CHUYỂN"
        }
        addBtn("🤝  TƯƠNG TÁC") { interact() }
        addBtn("📱  NHIỆM VỤ") { showMission() }
        addBtn("🏠  VÀO / RA NHÀ") {
            indoors=!indoors; game.setIndoor(indoors)
            hint.text=if(indoors) "BÊN TRONG NHÀ • TƯƠNG TÁC ĐỒ ĐẠC" else "THÀNH PHỐ • KHÁM PHÁ TỰ DO"
        }
        root.addView(buttons,FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT or Gravity.CENTER_VERTICAL).apply { rightMargin=14 })
        setContentView(root)
    }

    private fun interact() {
        val target=game.nearestTarget()
        when(target) {
            "Cửa hàng" -> AlertDialog.Builder(this).setTitle("🏪 Cửa hàng tạp hóa")
                .setItems(arrayOf("Nước suối - 5.000đ","Bánh mì - 15.000đ","Mũ bảo hiểm - 80.000đ")) { _,which ->
                    val cost=listOf(5000,15000,80000)[which]
                    if(money>=cost) { money-=cost; updateHud(); toast("Mua hàng thành công!") } else toast("Bạn không đủ tiền.")
                }.setNegativeButton("Đóng",null).show()
            "NPC: Cô bán hàng" -> dialogue("Cô bán hàng","Cháu cần mua gì không? Cô có thể giao cho cháu một đơn hàng đến khu dân cư.")
            "NPC: Cảnh sát" -> dialogue("Cảnh sát khu vực","Chào bạn! Hãy cùng giữ gìn an ninh, báo tin khi thấy sự cố và giúp đỡ người dân.")
            "NPC: Bác sĩ" -> dialogue("Bác sĩ","Bệnh viện đang cần người hỗ trợ đưa bệnh nhân đến quầy tiếp nhận.")
            "NPC: Người dân" -> dialogue("Người dân","Bạn có thể giúp tôi tìm đường đến chợ gần đây không?")
            "Đồn công an" -> dialogue("Đồn công an","Trung tâm tiếp nhận tin báo và nhiệm vụ an ninh cộng đồng.")
            "Bệnh viện" -> dialogue("Bệnh viện","Bạn đã hồi phục sức khỏe và năng lượng.")
            "Nhà tù" -> dialogue("Cơ sở cải tạo","Khu vực xử lý vi phạm giả lập trong trò chơi.")
            "Gara xe" -> dialogue("Gara xe","Bảo dưỡng xe và thay đổi màu sơn.")
            else -> toast("Hãy đến gần NPC hoặc công trình để tương tác.")
        }
    }
    private fun dialogue(title:String,msg:String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(msg)
            .setPositiveButton("Tiếp tục") { _,_ -> toast("Đã ghi nhận cuộc trò chuyện.") }
            .setNegativeButton("Đóng",null).show()
    }
    private fun showMission() {
        AlertDialog.Builder(this).setTitle("📋 Nhiệm vụ cộng đồng")
            .setMessage(if(missionDone) "Bạn đã hoàn thành nhiệm vụ giao hàng. Phần thưởng: 120.000đ." else "Giao một túi hàng từ cửa hàng đến khu dân cư.\\n\\nPhần thưởng: 120.000đ + 80 XP.")
            .setPositiveButton(if(missionDone) "Đã hoàn thành" else "Nhận nhiệm vụ") { _,_ ->
                if(!missionDone) { missionDone=true; money+=120000; updateHud(); toast("Nhiệm vụ demo hoàn thành +120.000đ") }
            }.setNegativeButton("Đóng",null).show()
    }
    private fun updateHud() { hud.text="VIETNAM LIFE 3D   •   CẤP 08\\n₫${"%,d".format(money)}   •   SÀI GÒN" }
    private fun toast(s:String) { hint.text=s }
    private fun bg(c:Int,r:Int)=GradientDrawable().apply { setColor(c); cornerRadius=r.toFloat() }

    override fun onPause() { super.onPause(); game.onPause() }
    override fun onResume() { super.onResume(); game.onResume() }
}

private class LifeGLView(ctx: android.content.Context) : GLSurfaceView(ctx) {
    private val renderer=LifeRenderer()
    private var lastX=0f
    private var lastY=0f
    private var rightDrag=false
    private var moveX=0f
    private var moveY=0f
    init {
        setEGLContextClientVersion(2)
        setRenderer(renderer)
        renderMode=RENDERMODE_CONTINUOUSLY
    }
    fun setRiding(v:Boolean) { renderer.riding=v }
    fun setIndoor(v:Boolean) { renderer.indoor=v }
    fun nearestTarget():String = renderer.nearestTarget()
    override fun onTouchEvent(e:MotionEvent):Boolean {
        val w=width.toFloat(); val h=height.toFloat()
        when(e.action) {
            MotionEvent.ACTION_DOWN -> {
                lastX=e.x; lastY=e.y; rightDrag=e.x>w*.55f
                if(!rightDrag) updateMove(e.x,e.y,w,h)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if(rightDrag) renderer.cameraYaw += (e.x-lastX)*0.006f
                else updateMove(e.x,e.y,w,h)
                lastX=e.x; lastY=e.y; return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                moveX=0f; moveY=0f; renderer.setMove(0f,0f); return true
            }
        }
        return true
    }
    private fun updateMove(x:Float,y:Float,w:Float,h:Float) {
        val cx=w*.17f; val cy=h*.77f
        val dx=(x-cx)/(w*.14f); val dy=(y-cy)/(h*.20f)
        val len=max(1f,sqrt(dx*dx+dy*dy))
        moveX=(dx/len).coerceIn(-1f,1f); moveY=(dy/len).coerceIn(-1f,1f)
        renderer.setMove(moveX,moveY)
    }
}

private class LifeRenderer : GLSurfaceView.Renderer {
    @Volatile var moveX=0f
    @Volatile var moveY=0f
    @Volatile var riding=false
    @Volatile var indoor=false
    @Volatile var cameraYaw=0f
    private var x=0f
    private var z=0f
    private var yaw=0f
    private var speed=0f
    private var program=0
    private var pos=0
    private var mvpLoc=0
    private var colorLoc=0
    private val projection=FloatArray(16)
    private val view=FloatArray(16)
    private val model=FloatArray(16)
    private val temp=FloatArray(16)
    private val mvp=FloatArray(16)
    private val cube=java.nio.ByteBuffer.allocateDirect(36*3*4).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer()
    private val verts=floatArrayOf(
        -0.5f,-0.5f,0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f,
        0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f,
        -0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f,
        0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f,
        -0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f,
        -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f
    )
    private val vs="""attribute vec3 aPos; uniform mat4 uMVP; void main(){ gl_Position=uMVP*vec4(aPos,1.0); }"""
    private val fs="""precision mediump float; uniform vec4 uColor; void main(){ gl_FragColor=uColor; }"""

    fun setMove(x:Float,y:Float) { moveX=x; moveY=y }
    fun nearestTarget():String {
        val choices=listOf("NPC: Cô bán hàng","NPC: Cảnh sát","NPC: Bác sĩ","NPC: Người dân","Cửa hàng","Đồn công an","Bệnh viện","Nhà tù","Gara xe")
        return when {
            abs(x+12f)<9f && abs(z+13f)<9f -> "Cửa hàng"
            abs(x-25f)<9f && abs(z-2f)<9f -> "Đồn công an"
            abs(x+14f)<9f && abs(z-12f)<9f -> "Bệnh viện"
            abs(x-4f)<9f && abs(z-27f)<9f -> "Nhà tù"
            abs(x-25f)<10f && abs(z-2f)<10f -> "Gara xe"
            else -> when {
                hypot(x+4f,z+8f)<8f -> "NPC: Cô bán hàng"
                hypot(x-8f,z-5f)<8f -> "NPC: Cảnh sát"
                hypot(x+10f,z-10f)<8f -> "NPC: Bác sĩ"
                else -> "NPC: Người dân"
            }
        }
    }
    override fun onSurfaceCreated(gl:javax.microedition.khronos.opengles.GL10?, config:javax.microedition.khronos.egl.EGLConfig?) {
        android.opengl.GLES20.glClearColor(0.40f,0.67f,0.78f,1f)
        android.opengl.GLES20.glEnable(android.opengl.GLES20.GL_DEPTH_TEST)
        val v=shader(android.opengl.GLES20.GL_VERTEX_SHADER,vs)
        val f=shader(android.opengl.GLES20.GL_FRAGMENT_SHADER,fs)
        program=android.opengl.GLES20.glCreateProgram()
        android.opengl.GLES20.glAttachShader(program,v); android.opengl.GLES20.glAttachShader(program,f)
        android.opengl.GLES20.glLinkProgram(program)
        pos=android.opengl.GLES20.glGetAttribLocation(program,"aPos")
        mvpLoc=android.opengl.GLES20.glGetUniformLocation(program,"uMVP")
        colorLoc=android.opengl.GLES20.glGetUniformLocation(program,"uColor")
        cube.put(verts).position(0)
    }
    private fun shader(type:Int,src:String):Int {
        val s=android.opengl.GLES20.glCreateShader(type)
        android.opengl.GLES20.glShaderSource(s,src); android.opengl.GLES20.glCompileShader(s); return s
    }
    override fun onSurfaceChanged(gl:javax.microedition.khronos.opengles.GL10?,w:Int,h:Int) {
        android.opengl.GLES20.glViewport(0,0,w,h)
        android.opengl.Matrix.perspectiveM(projection,0,55f,w.toFloat()/max(1,h),0.1f,250f)
    }
    override fun onDrawFrame(gl:javax.microedition.khronos.opengles.GL10?) {
        android.opengl.GLES20.glClear(android.opengl.GLES20.GL_COLOR_BUFFER_BIT or android.opengl.GLES20.GL_DEPTH_BUFFER_BIT)
        val inputForward=-moveY
        val inputSide=moveX
        if(abs(inputForward)+abs(inputSide)>.05f) {
            yaw=atan2(inputSide,inputForward)
            speed += (if(riding) .014f else .006f)
        } else speed*=.88f
        val maxSpeed=if(riding) .23f else .085f
        speed=speed.coerceIn(0f,maxSpeed)
        x += sin(yaw)*speed*if(abs(inputForward)>.05f) sign(inputForward) else 1f
        z += -cos(yaw)*speed*if(abs(inputForward)>.05f) sign(inputForward) else 1f
        val camYaw=yaw+cameraYaw
        val camX=x-sin(camYaw)*7.5f
        val camZ=z+cos(camYaw)*7.5f
        android.opengl.Matrix.setLookAtM(view,0,camX,4.2f,camZ,x,1f,z,0f,1f,0f)
        val camYaw=yaw+cameraYaw
        val camX=x-sin(camYaw)*8f
        val camZ=z+cos(camYaw)*8f
        android.opengl.Matrix.setLookAtM(view,0,camX,5.0f,camZ,x,1f,z,0f,1f,0f)
        android.opengl.GLES20.glUseProgram(shaderProgram)
        if(indoor) drawInterior() else drawCity()
        drawPlayer()
    }
    private fun drawCity() {
        box(0f,-.18f,0f,80f,.3f,80f,0.19f,0.42f,0.30f)
        // road grid
        for(i in -8..8) {
            box(i*5f,.005f,0f,1.7f,.03f,80f,.25f,.27f,.29f)
            box(0f,.008f,i*5f,80f,.03f,1.7f,.25f,.27f,.29f)
        }
        // lane marks
        for(i in -7..7) for(j in -7..7) {
            box(i*5f,.03f,j*5f, .13f,.02f,1.1f,.91f,.82f,.55f)
        }
        // buildings distributed around broad district
        val buildings=listOf(
            floatArrayOf(-12f,0f,-12f,5f,5f,5f), floatArrayOf(12f,0f,-13f,6f,7f,5f),
            floatArrayOf(-14f,0f,12f,6f,5f,7f), floatArrayOf(13f,0f,13f,7f,6f,6f),
            floatArrayOf(-25f,0f,-2f,6f,8f,8f), floatArrayOf(25f,0f,2f,7f,7f,7f),
            floatArrayOf(-3f,0f,-27f,8f,8f,6f), floatArrayOf(4f,0f,27f,8f,7f,7f)
        )
        buildings.forEachIndexed { i,b ->
            val col=when(i%4){0->floatArrayOf(.78f,.48f,.31f);1->floatArrayOf(.36f,.55f,.70f);2->floatArrayOf(.72f,.68f,.49f);else->floatArrayOf(.55f,.42f,.66f)}
            box(b[0],b[1]+b[4]/2,b[2],b[3],b[4],b[5],col[0],col[1],col[2])
            box(b[0],b[1]+b[4]+.25f,b[2],b[3]+.5f,.5f,b[5]+.5f,.23f,.19f,.18f)
            for(wx in -1..1) box(b[0]+wx*b[3]*.25f,b[1]+b[4]*.58f,b[2]+b[5]/2+.02f,.55f,.7f,.05f,.28f,.68f,.78f)
        }
        // park trees
        for(i in -3..3) for(j in -3..3) {
            val tx= i*3.0f+33f; val tz=j*3.0f-31f
            box(tx,.65f,tz,.25f,1.3f,.25f,.36f,.22f,.12f)
            box(tx,1.7f,tz,1.3f,1.5f,1.3f,.13f,.48f,.25f)
        }
        // NPCs
        drawNpc(-4f,0f,-8f,.15f,.75f,.92f)
        drawNpc(8f,0f,5f,.9f,.68f,.24f)
        drawNpc(-10f,0f,10f,.24f,.55f,.83f)
        // parked motorcycle
        drawBike(3f,0f,-4f,0f)
    }
    private fun drawInterior() {
        box(0f,-.15f,0f,12f,.3f,12f,.52f,.42f,.31f)
        box(0f,2.4f,-6f,12f,4.8f,.2f,.82f,.77f,.65f)
        box(-6f,2.4f,0f,.2f,4.8f,12f,.75f,.68f,.56f)
        box(6f,2.4f,0f,.2f,4.8f,12f,.75f,.68f,.56f)
        box(0f,4.8f,0f,12f,.2f,12f,.42f,.32f,.25f)
        box(-2f,.5f,-2f,2f,1f,1.4f,.40f,.19f,.12f)
        box(2f,.45f,1f,1.5f,.9f,1.5f,.15f,.30f,.42f)
        box(0f,1.3f,-5.8f,2f,1.4f,.1f,.25f,.65f,.7f)
    }
    private fun drawPlayer() {
        if(riding) drawBike(x,0f,z,yaw)
        else {
            box(x,.65f,z,.65f,1.25f,.42f,.12f,.56f,.72f)
            box(x,1.55f,z,.48f,.48f,.48f,.84f,.66f,.52f)
            box(x-.2f,.16f,z,.18f,.4f,.2f,.12f,.13f,.18f)
            box(x+.2f,.16f,z,.18f,.4f,.2f,.12f,.13f,.18f)
        }
    }
    private fun drawNpc(x:Float,y:Float,z:Float,r:Float,g:Float,b:Float) {
        box(x,.6f,z,.55f,1.1f,.4f,r,g,b)
        box(x,1.42f,z,.42f,.42f,.42f,.82f,.65f,.51f)
    }
    private fun drawBike(x:Float,y:Float,z:Float,rot:Float) {
        box(x,.58f,z,.45f,.45f,1.6f,.78f,.12f,.08f,rot)
        cylinder(x-.27f,.28f,z-.52f,.28f,.12f,.12f,.13f,.15f,rot)
        cylinder(x-.27f,.28f,z+.52f,.28f,.12f,.12f,.13f,.15f,rot)
        box(x,.88f,z-.12f,.65f,.2f,.42f,.16f,.18f,.22f,rot)
        box(x,1.12f,z+.05f,.24f,.45f,.25f,.85f,.2f,.08f,rot)
    }

    private fun box(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,r:Float,g:Float,b:Float,rot:Float=0f) {
        android.opengl.Matrix.setIdentityM(model,0)
        android.opengl.Matrix.translateM(model,0,x,y,z)
        if(rot!=0f) android.opengl.Matrix.rotateM(model,0,Math.toDegrees(rot.toDouble()).toFloat(),0f,1f,0f)
        android.opengl.Matrix.scaleM(model,0,sx,sy,sz)
        drawMesh(r,g,b)
    }
    private val model=FloatArray(16); private val mvp=FloatArray(16); private val temp=FloatArray(16)
    private val view=FloatArray(16); private val projection=FloatArray(16)
    private val vertices=java.nio.ByteBuffer.allocateDirect(36*3*4).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer()
    private val cubeVerts=floatArrayOf(
        -.5f,-.5f,.5f,.5f,-.5f,.5f,.5f,.5f,.5f, -.5f,-.5f,.5f,.5f,.5f,.5f,-.5f,.5f,.5f,
        .5f,-.5f,-.5f,-.5f,-.5f,-.5f,-.5f,.5f,-.5f, .5f,-.5f,-.5f,-.5f,.5f,-.5f,.5f,.5f,-.5f,
        -.5f,-.5f,-.5f,-.5f,-.5f,.5f,-.5f,.5f,.5f, -.5f,-.5f,-.5f,-.5f,.5f,.5f,-.5f,.5f,-.5f,
        .5f,-.5f,.5f,.5f,-.5f,-.5f,.5f,.5f,-.5f, .5f,-.5f,.5f,.5f,.5f,-.5f,.5f,.5f,.5f,
        -.5f,.5f,.5f,.5f,.5f,.5f,.5f,.5f,-.5f, -.5f,.5f,.5f,.5f,.5f,-.5f,-.5f,.5f,-.5f,
        -.5f,-.5f,-.5f,.5f,-.5f,-.5f,.5f,-.5f,.5f, -.5f,-.5f,-.5f,.5f,-.5f,.5f,-.5f,-.5f,.5f
    )
    private var shaderProgram=0; private var aPos=0; private var uMvp=0; private var uColor=0
    private fun drawMesh(r:Float,g:Float,b:Float) {
        android.opengl.Matrix.multiplyMM(temp,0,view,0,model,0)
        android.opengl.Matrix.multiplyMM(mvp,0,projection,0,temp,0)
        val gl=android.opengl.GLES20
        gl.glUniformMatrix4fv(uMvp,1,false,mvp,0)
        gl.glUniform4f(uColor,r,g,b,1f)
        vertices.position(0); gl.glVertexAttribPointer(aPos,3,gl.GL_FLOAT,false,0,vertices)
        gl.glEnableVertexAttribArray(aPos); gl.glDrawArrays(gl.GL_TRIANGLES,0,36)
    }
    private fun cylinder(x:Float,y:Float,z:Float,rad:Float,depth:Float,r:Float,g:Float,b:Float,rot:Float) {
        // Wheel cylinder approximation using 12-sided radial box segments.
        for(i in 0 until 12) {
            val a=i*PI.toFloat()/6f
            val xx=x+cos(a)*rad*.5f; val zz=z+sin(a)*rad*.5f
            box(xx,y,zz,rad*.35f,depth,rad*.35f,r,g,b,rot)
        }
    }
}
