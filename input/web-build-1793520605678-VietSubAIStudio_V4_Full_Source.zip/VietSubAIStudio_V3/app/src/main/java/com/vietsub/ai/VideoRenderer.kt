package com.vietsub.ai

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.os.Build
import android.provider.MediaStore
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max

class VideoRenderer(private val context: Context) {

    suspend fun render(
        source: File,
        subs: List<Subtitle>,
        voiceFiles: List<File>,
        workDir: File,
        outputName: String,
        onProgress: (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        require(subs.isNotEmpty() && subs.size == voiceFiles.size) { "Thiếu phụ đề hoặc giọng đọc." }
        val srt = File(workDir, "captions.srt").apply { writeText(SubtitleExporter.srt(subs), Charsets.UTF_8) }
        val output = File(workDir, "rendered.mp4")
        val command = buildCommand(source, srt, subs, voiceFiles, output)
        onProgress("Đang ghép giọng Việt và phụ đề...")
        val session = suspendCancellableCoroutine { cont ->
            FFmpegKit.executeAsync(command) { session ->
                if (!cont.isActive) return@executeAsync
                val rc = session.returnCode
                if (ReturnCode.isSuccess(rc) && output.exists() && output.length() > 1024) {
                    cont.resume(session)
                } else {
                    val logs = session.allLogsAsString
                    cont.resumeWithException(IllegalStateException("FFmpeg lỗi: ${logs.takeLast(1600)}"))
                }
            }
        }
        onProgress("Đang lưu MP4 vào Movies/VietSubAI...")
        saveToMovies(output, outputName)
    }

    private fun buildCommand(source: File, srt: File, subs: List<Subtitle>, voices: List<File>, output: File): String {
        val args = mutableListOf("-y", "-i", quote(source.absolutePath))
        voices.forEach { args += listOf("-i", quote(it.absolutePath)) }

        val filters = mutableListOf<String>()
        val labels = mutableListOf<String>()
        voices.forEachIndexed { index, file ->
            val input = index + 1
            val targetMs = max(400L, subs[index].end - subs[index].start)
            val duration = wavDurationMs(file).coerceAtLeast(1)
            val speed = (duration.toDouble() / targetMs.toDouble()).coerceIn(0.70, 1.50)
            val delay = subs[index].start.coerceAtLeast(0)
            val label = "v$index"
            filters += "[$input:a]atempo=${"%.3f".format(java.util.Locale.US, speed)},adelay=$delay|$delay[$label]"
            labels += "[$label]"
        }
        filters += labels.joinToString("") + "amix=inputs=${labels.size}:duration=longest:dropout_transition=0,alimiter=limit=0.95[aout]"

        val srtPath = srt.absolutePath.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
        val filterGraph = filters.joinToString(";")
        args += listOf(
            "-filter_complex", quote(filterGraph),
            "-map", "0:v:0", "-map", "[aout]",
            "-vf", quote("subtitles='$srtPath':force_style='FontName=Arial,FontSize=22,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=1,Alignment=2,MarginV=35'"),
            "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23",
            "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart",
            "-shortest", quote(output.absolutePath)
        )
        return args.joinToString(" ")
    }

    private fun wavDurationMs(file: File): Long {
        // PCM WAV duration = data bytes / byte rate. TTS output is normally PCM WAV.
        RandomAccessFileCompat(file).use { raf ->
            if (raf.length() < 44) return 1000
            raf.seek(28)
            val byteRate = raf.readIntLE().toLong()
            raf.seek(40)
            val dataSize = raf.readIntLE().toLong().coerceAtLeast(0)
            if (byteRate <= 0) return 1000
            return dataSize * 1000 / byteRate
        }
    }

    private fun saveToMovies(file: File, requestedName: String): String {
        val name = requestedName.substringBeforeLast('.', requestedName).replace(Regex("[^A-Za-z0-9_-]"), "_") + "_vietsub.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VietSubAI")
        }
        val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Không tạo được file trong Movies/VietSubAI.")
        try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(file).use { input -> input.copyTo(out) }
            } ?: error("Không mở được file đầu ra.")
        } catch (e: Exception) {
            context.contentResolver.delete(uri, null, null)
            throw e
        }
        return "Đã lưu: Movies/VietSubAI/$name"
    }

    private fun quote(s: String) = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
}

/** Tiny little-endian reader to avoid loading WAV audio into memory. */
private class RandomAccessFileCompat(file: File) : java.io.RandomAccessFile(file, "r") {
    fun readIntLE(): Int {
        val a = read()
        val b = read()
        val c = read()
        val d = read()
        return (d shl 24) or (c shl 16) or (b shl 8) or a
    }
}
