package com.vietsub.ai

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { MainScreen(this) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScreen(context: Context) {
    val scope = rememberCoroutineScope()
    var apiKey by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("gemini-2.5-flash") }
    var glossary by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("Tự nhiên, đúng ngữ cảnh, tiếng Việt dễ hiểu") }
    var rate by remember { mutableFloatStateOf(1.0f) }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("Chưa chọn video") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Chọn video để bắt đầu.") }
    var error by remember { mutableStateOf("") }
    var subtitles by remember { mutableStateOf(emptyList<Subtitle>()) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        if (picked != null) {
            uri = picked
            videoName = queryName(context, picked)
            context.contentResolver.takePersistableUriPermission(picked, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("VietSub AI Studio 2.0") }) }) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Dịch phim Trung → Việt và tự xuất MP4 có giọng Việt", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(apiKey, { apiKey = it }, Modifier.fillMaxWidth(), label = { Text("Gemini API Key") }, singleLine = true)
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Gemini model") }, singleLine = true,
                supportingText = { Text("Tên model phải được tài khoản/API key của bạn hỗ trợ.") })
            OutlinedTextField(glossary, { glossary = it }, Modifier.fillMaxWidth(), label = { Text("Từ điển / tên nhân vật") }, minLines = 2)
            OutlinedTextField(style, { style = it }, Modifier.fillMaxWidth(), label = { Text("Phong cách dịch") }, minLines = 2)
            Text("Tốc độ giọng đọc: ${"%.1f".format(rate)}x")
            Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.75f..1.25f)
            OutlinedButton(onClick = { picker.launch(arrayOf("video/*")) }, Modifier.fillMaxWidth()) {
                Text("Chọn video")
            }
            Text(videoName, style = MaterialTheme.typography.bodySmall)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Cấu hình âm thanh", style = MaterialTheme.typography.titleSmall)
                    Text("Âm thanh gốc tiếng Trung: TẮT HOÀN TOÀN")
                    Text("Âm thanh đầu ra: chỉ có giọng đọc tiếng Việt")
                    Text("Phụ đề tiếng Việt: ghép trực tiếp vào hình ảnh")
                }
            }
            Button(
                enabled = !busy && uri != null && apiKey.isNotBlank(),
                onClick = {
                    val selected = uri ?: return@Button
                    busy = true; error = ""; subtitles = emptyList()
                    scope.launch {
                        try {
                            val work = File(context.cacheDir, "vietsub_job").apply {
                                deleteRecursively(); mkdirs()
                            }
                            status = "1/4 — Đang gửi video và dịch bằng Gemini..."
                            val translated = GeminiVideoService(context).translateVideo(selected, apiKey.trim(), model.trim(), glossary, style)
                            require(translated.isNotEmpty()) { "Gemini không nhận diện được câu thoại nào." }
                            subtitles = translated

                            status = "2/4 — Đang tạo giọng đọc tiếng Việt..."
                            val voices = VietnameseTts(context).render(translated, work, rate)

                            status = "3/4 — Đang chuẩn bị video..."
                            val source = File(work, "source_video")
                            context.contentResolver.openInputStream(selected)?.use { input ->
                                FileOutputStream(source).use { output -> input.copyTo(output) }
                            } ?: error("Không đọc được video nguồn.")

                            status = "4/4 — Đang ghép MP4 (đã loại bỏ tiếng Trung)..."
                            val result = VideoRenderer(context).render(
                                source, translated, voices, work, videoName
                            ) { progress -> status = progress }
                            status = result
                        } catch (e: Exception) {
                            error = e.message ?: "Có lỗi không xác định."
                            status = "Không hoàn tất."
                        } finally {
                            busy = false
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                else Text("DỊCH VÀ XUẤT MP4 TỰ ĐỘNG")
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Text(status, style = MaterialTheme.typography.bodyMedium)
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            if (subtitles.isNotEmpty()) {
                Text("Đã nhận diện ${subtitles.size} đoạn thoại.", style = MaterialTheme.typography.titleSmall)
                subtitles.take(5).forEachIndexed { i, s ->
                    Text("${i + 1}. ${SubtitleExporter.time(s.start)}  ${s.text}", style = MaterialTheme.typography.bodySmall)
                }
            }
            Text(
                "Lưu ý: cần cài giọng tiếng Việt trong cài đặt Text-to-Speech của Android. Chất lượng giọng tùy engine trên điện thoại. Video được tải lên Google Gemini để dịch.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary
            )
        }
    }
}

private fun queryName(context: Context, uri: Uri): String {
    var name = "video.mp4"
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) name = it.getString(0) ?: name
    }
    return name
}
