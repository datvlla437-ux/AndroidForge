package com.vietsub.ai

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.Bundle
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Uses the Vietnamese voice installed on the Android device.
 * No paid TTS API key is required. Voice quality depends on installed TTS engine.
 */
class VietnameseTts(private val context: Context) {
    suspend fun render(subtitles: List<Subtitle>, workDir: File, rate: Float = 1.0f): List<File> {
        val engine = createEngine()
        try {
            val vi = engine.availableLanguages.firstOrNull { it.language == "vi" }
                ?: Locale("vi", "VN")
            val languageResult = engine.setLanguage(vi)
            require(languageResult != TextToSpeech.LANG_MISSING_DATA &&
                    languageResult != TextToSpeech.LANG_NOT_SUPPORTED) {
                "Điện thoại chưa có giọng đọc tiếng Việt. Cài giọng Vietnamese trong cài đặt Text-to-Speech của Android."
            }
            engine.setSpeechRate(rate.coerceIn(0.75f, 1.25f))
            val outputs = mutableListOf<File>()
            subtitles.forEachIndexed { index, sub ->
                val file = File(workDir, "voice_%04d.wav".format(index))
                synthesize(engine, sub.text, file, "vsub_$index")
                require(file.exists() && file.length() > 44) { "Không tạo được âm thanh cho câu ${index + 1}." }
                outputs += file
            }
            return outputs
        } finally {
            engine.stop()
            engine.shutdown()
        }
    }

    private suspend fun createEngine(): TextToSpeech = suspendCancellableCoroutine { cont ->
        lateinit var tts: TextToSpeech
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                if (cont.isActive) cont.resume(tts) else tts.shutdown()
            } else if (cont.isActive) cont.resumeWithException(IllegalStateException("Không khởi tạo được Text-to-Speech Android."))
        }
        cont.invokeOnCancellation { tts.shutdown() }
    }

    private suspend fun synthesize(tts: TextToSpeech, text: String, file: File, id: String) =
        suspendCancellableCoroutine<Unit> { cont ->
            val completed = AtomicBoolean(false)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (completed.compareAndSet(false, true) && cont.isActive) cont.resume(Unit)
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (completed.compareAndSet(false, true) && cont.isActive)
                        cont.resumeWithException(IllegalStateException("Lỗi tạo giọng đọc tiếng Việt."))
                }
                override fun onError(utteranceId: String?, errorCode: Int) = onError(utteranceId)
            })
            val params = Bundle()
            val result = tts.synthesizeToFile(text, params, file, id)
            if (result != TextToSpeech.SUCCESS && completed.compareAndSet(false, true) && cont.isActive) {
                cont.resumeWithException(IllegalStateException("Text-to-Speech từ chối tạo file âm thanh."))
            }
        }
}
