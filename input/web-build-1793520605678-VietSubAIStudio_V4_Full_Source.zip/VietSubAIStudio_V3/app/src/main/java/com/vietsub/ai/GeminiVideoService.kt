package com.vietsub.ai

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class GeminiVideoService(private val context: Context) {
    suspend fun translateVideo(uri: Uri, apiKey: String, model: String, glossary: String, style: String): List<Subtitle> =
        withContext(Dispatchers.IO) {
            require(apiKey.isNotBlank()) { "Bạn chưa nhập Gemini API Key." }
            require(model.isNotBlank()) { "Bạn chưa nhập tên model." }
            val mime = context.contentResolver.getType(uri) ?: "video/mp4"
            val name = getName(uri)
            val data = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Không đọc được video.")
            require(data.isNotEmpty()) { "Video rỗng." }
            require(data.size <= 180 * 1024 * 1024) { "Video vượt giới hạn 180 MB của bản này. Hãy cắt video ngắn hơn." }

            val file = upload(apiKey, name, mime, data)
            val resourceName = file.optString("name")
            val fileUri = file.optString("uri")
            require(resourceName.isNotBlank() && fileUri.isNotBlank()) {
                "Gemini không trả về file URI. Kiểm tra API key và quyền Files API."
            }
            waitActive(apiKey, resourceName)

            val prompt = """
Bạn là hệ thống tạo phụ đề phim chuyên nghiệp. Nghe lời thoại tiếng Trung trong video và dịch sang tiếng Việt.
CHỈ trả JSON hợp lệ, không Markdown. Schema:
{"subtitles":[{"start":"00:00:01.200","end":"00:00:03.500","text":"Câu tiếng Việt"}]}
Quy tắc:
- Timestamp tính từ đầu video, định dạng HH:MM:SS.mmm.
- Tạo đoạn theo từng câu/ý thoại, không gom các câu xa nhau.
- Bám sát lời nói, dịch tự nhiên, giữ tên nhân vật theo từ điển.
- Không thêm lời không có trong video. Nếu không nghe rõ, bỏ qua đoạn đó.
- Thời gian phải tăng dần, end lớn hơn start.
Phong cách: $style
Từ điển/tên nhân vật: ${glossary.ifBlank { "Không có" }}
            """.trimIndent()

            val req = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                    .put(JSONObject().put("fileData", JSONObject().put("mimeType", mime).put("fileUri", fileUri)))
                    .put(JSONObject().put("text", prompt)))))
                put("generationConfig", JSONObject().put("temperature", 0.15).put("responseMimeType", "application/json"))
            }
            val response = postJson(
                "https://generativelanguage.googleapis.com/v1beta/models/${enc(model)}:generateContent?key=${enc(apiKey)}",
                req
            )
            val answer = response.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            parse(answer)
        }

    private fun upload(key: String, filename: String, mime: String, bytes: ByteArray): JSONObject {
        val boundary = "----VietSub${UUID.randomUUID()}"
        val conn = (URL("https://generativelanguage.googleapis.com/upload/v1beta/files?key=${enc(key)}").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true
            connectTimeout = 30_000; readTimeout = 180_000
            setRequestProperty("X-Goog-Upload-Protocol", "multipart")
            setRequestProperty("Content-Type", "multipart/related; boundary=$boundary")
        }
        conn.outputStream.use { out ->
            out.write("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n".toByteArray())
            out.write("""{"file":{"display_name":${JSONObject.quote(filename)}}}""".toByteArray())
            out.write("\r\n--$boundary\r\nContent-Type: $mime\r\n\r\n".toByteArray())
            out.write(bytes)
            out.write("\r\n--$boundary--".toByteArray())
        }
        return read(conn)
    }

    private fun waitActive(key: String, name: String) {
        repeat(36) {
            val c = (URL("https://generativelanguage.googleapis.com/v1beta/$name?key=${enc(key)}").openConnection() as HttpURLConnection).apply {
                connectTimeout = 20_000; readTimeout = 30_000
            }
            val obj = read(c)
            when (obj.optString("state")) {
                "ACTIVE" -> return
                "FAILED" -> error("Gemini không xử lý được video.")
            }
            Thread.sleep(2_000)
        }
        error("Gemini xử lý video quá lâu. Hãy thử clip ngắn hơn.")
    }

    private fun postJson(url: String, body: JSONObject): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true
            connectTimeout = 30_000; readTimeout = 240_000
            setRequestProperty("Content-Type", "application/json")
        }
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return read(c)
    }

    private fun read(c: HttpURLConnection): JSONObject {
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (code !in 200..299) {
            val msg = try { JSONObject(body).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
            error("Gemini HTTP $code: ${msg ?: body.take(400)}")
        }
        return JSONObject(body)
    }

    private fun parse(raw: String): List<Subtitle> {
        val clean = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val arr = JSONObject(clean).getJSONArray("subtitles")
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val start = SubtitleExporter.parseTime(o.getString("start"))
                val end = SubtitleExporter.parseTime(o.getString("end"))
                val text = o.getString("text").trim()
                if (start >= 0 && end > start && text.isNotBlank()) add(Subtitle(start, end, text))
            }
        }.sortedBy { it.start }
    }

    private fun getName(uri: Uri): String {
        var n = "video.mp4"
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) n = it.getString(0) ?: n
        }
        return n
    }
    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8")
}
