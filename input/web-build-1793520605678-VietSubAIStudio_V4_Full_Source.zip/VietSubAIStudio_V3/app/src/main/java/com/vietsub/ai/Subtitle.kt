package com.vietsub.ai

data class Subtitle(val start: Long, val end: Long, val text: String)

object SubtitleExporter {
    fun srt(items: List<Subtitle>): String = items.mapIndexed { i, s ->
        "${i + 1}\n${time(s.start)} --> ${time(s.end)}\n${s.text}\n"
    }.joinToString("\n")

    fun time(ms: Long): String =
        "%02d:%02d:%02d,%03d".format(ms / 3_600_000, (ms / 60_000) % 60, (ms / 1_000) % 60, ms % 1_000)

    fun parseTime(value: String): Long {
        val p = value.replace(',', '.').split(":")
        require(p.size == 3) { "Timestamp không hợp lệ: $value" }
        val sec = p[2].split(".")
        val milli = (sec.getOrNull(1) ?: "0").padEnd(3, '0').take(3).toLong()
        return p[0].toLong() * 3_600_000 + p[1].toLong() * 60_000 + sec[0].toLong() * 1_000 + milli
    }
}
