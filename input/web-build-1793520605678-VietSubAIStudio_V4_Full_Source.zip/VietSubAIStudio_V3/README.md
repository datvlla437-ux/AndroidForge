# VietSub AI Studio 2.0 — Full Android source

## Mục tiêu
Chọn video tiếng Trung → Gemini tạo phụ đề/dịch Việt có timestamp → Android Text-to-Speech tạo giọng Việt → FFmpeg dựng MP4 mới, **không lấy track âm thanh gốc**, chỉ có tiếng Việt → lưu tự động vào `Movies/VietSubAI/`.

## Chức năng
- Android 10+, Kotlin, Jetpack Compose.
- Nhập Gemini API key/model.
- Chọn video qua Android Storage Access Framework.
- Gemini Files API + generateContent.
- Từ điển nhân vật, phong cách dịch.
- Tạo file giọng đọc WAV cho từng câu bằng TTS tiếng Việt có sẵn trên máy.
- Căn thời gian giọng đọc theo timestamp; ghép các đoạn thoại.
- Burn-in phụ đề tiếng Việt lên hình.
- Loại bỏ hoàn toàn audio gốc bằng cách chỉ map video stream và audio track TTS.
- Lưu MP4 vào `Movies/VietSubAI/`.

## Build
1. Mở thư mục này bằng Android Studio.
2. Dùng JDK 17, cài Android SDK Platform 35.
3. Gradle Sync.
4. Build > Build APK(s).
5. APK debug ở `app/build/outputs/apk/debug/app-debug.apk`.

## Dependency quan trọng
Dùng FFmpegKit community fork:
`dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl:8.1.7`
Nếu Gradle không resolve được artifact, cần thay bằng một FFmpegKit fork/repository đang hoạt động tương thích API `com.arthenica.ffmpegkit`. FFmpegKit upstream đã ngừng phát triển; kiểm tra giấy phép GPL và nghĩa vụ phân phối trước khi phát hành APK công khai.

## Lưu ý / giới hạn cần biết
- Đây là source project, chưa được build/test thành APK trong môi trường này.
- Model gợi ý `gemini-2.5-flash` chỉ là giá trị mặc định; nhập model thực tế mà API key của bạn có quyền sử dụng. Tên `gemini-3.8-flash` không được xác nhận.
- Gemini video understanding không đảm bảo timestamp chính xác tuyệt đối. Cần xem lại các mốc thời gian nếu video dài hoặc thoại nhanh.
- TTS dùng giọng Vietnamese có trên thiết bị Android, không phải giọng AI cloud cao cấp. Cài thêm Vietnamese voice data nếu máy chưa có.
- Bản này giữ hình ảnh gốc, loại bỏ hoàn toàn âm thanh gốc và tạo track tiếng Việt. Nhạc nền gốc cũng bị loại bỏ vì yêu cầu tắt toàn bộ tiếng Trung; không có tách riêng lời thoại khỏi nhạc nền.
- File video được đọc vào RAM khi upload, giới hạn 180 MB để tránh lỗi bộ nhớ. Nên dùng clip ngắn.
- Tốc độ TTS có thể bị điều chỉnh nhẹ để khớp thời lượng câu; nếu câu dài quá timestamp, tốc độ được giới hạn để giọng không bị méo quá mức.
- Chỉ xử lý một video mỗi lần; chưa có batch queue, resume sau khi app bị đóng, subtitle editor chuyên sâu, hay lựa chọn giọng cloud.
- Video upload lên Google Gemini. API key không được lưu vào source hoặc tự động ghi xuống ổ đĩa.
- FFmpeg encode video sẽ tốn CPU và pin; không khóa màn hình/thoát app trong lúc render để tránh hệ thống dừng tiến trình.


## V3 build fix (2026-11-01)
- Replaced the inaccessible JitPack dependency `io.github.junkfood:ffmpeg-kit-full-gpl:2.1.0` with the Maven Central artifact `dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl:8.1.7`.
- FFmpegKit-compatible API package remains `com.arthenica.ffmpegkit`, so VideoRenderer call sites are unchanged.
- This full-GPL variant is licensed under GPL-3.0; review the license obligations before distributing a closed-source/commercial APK.
- AndroidForge should use JDK 17 / Gradle 8.9 as detected. The project does not require compiling native code in this app module; leave “Force install NDK” unchecked unless the builder specifically requires it.
- This ZIP has not been compiled in the user's AndroidForge environment. If the next build fails, share the new build log; this update addresses the exact JitPack HTTP 401 shown in the previous log.


## V4 build fix (2026-11-01)
- Fixed Kotlin compile error in `VideoRenderer.kt`: Java `RandomAccessFile.length()` must be called as a method (`length()`), not accessed as a Kotlin property.
- This update addresses the exact `Function invocation length() expected` error reported by AndroidForge run #2.
- Not yet verified by a successful AndroidForge build; further errors may appear after compilation proceeds.
